+++++++++++++++++++++++++++++++++++
++                               ++
++   getRelated                  ++
++   Developer:  Mark Hamstra    ++
++   License:    GPL GNU v2      ++
++                               ++
+++++++++++++++++++++++++++++++++++

getRelated is a snippet for MODX Revolution that automatically finds related pages based on fields you specify.

It has been developed by Mark Hamstra for Vierkante Meter.

Forum Discussion:   http://forums.modx.com/thread/71009/getrelated-automatically-listing-related-resources-for-revolution
Documentation: 		http://rtfm.modx.com/display/ADDON/getRelated
Bugs & Features: 	https://github.com/Mark-H/getRelated/issues
Commercial Support:	hello@markhamstra.com